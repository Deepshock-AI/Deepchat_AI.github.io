import React, { useState } from "react";
import logo from './logo.png'; // Logo import

function App() {
  const [message, setMessage] = useState("");
  const [reply, setReply] = useState("");

  const handleChat = async () => {
    const res = await fetch("http://localhost:5000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    const data = await res.json();
    setReply(data.reply);
  };

  return (
    <div style={{ padding: "2rem", fontFamily: "Arial" }}>
      <img src={logo} alt="Deep Chat Logo" style={{ width: "120px", height: "120px", marginBottom: "20px" }} />
      <h1>Deep Chat</h1>
      <input
        type="text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="اپنا پیغام لکھیں"
        style={{ padding: "0.5rem", width: "300px" }}
      />
      <button onClick={handleChat} style={{ marginLeft: "1rem", padding: "0.5rem" }}>
        Send
      </button>
      <div style={{ marginTop: "1rem" }}>
        <strong>جواب:</strong> {reply}
      </div>
    </div>
  );
}

export default App;