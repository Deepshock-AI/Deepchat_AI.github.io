from flask import Flask, request, jsonify
from flask_cors import CORS
import openai
import base64
import os
from googletrans import Translator
from gtts import gTTS
import uuid
import subprocess
from PIL import Image

app = Flask(__name__)
CORS(app)
translator = Translator()
openai.api_key = 'YOUR_OPENAI_API_KEY'

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    msg = data['message']
    lang = translator.detect(msg).lang
    en_msg = translator.translate(msg, src=lang, dest='en').text
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": en_msg}]
    )
    reply_en = response.choices[0].message['content']
    reply_user_lang = translator.translate(reply_en, src='en', dest=lang).text
    return jsonify({"reply": reply_user_lang})

@app.route('/image', methods=['POST'])
def generate_image():
    data = request.get_json()
    prompt = data['prompt']
    response = openai.Image.create(prompt=prompt, n=1, size="512x512")
    return jsonify({"url": response['data'][0]['url']})

@app.route('/convert', methods=['POST'])
def convert_text():
    data = request.get_json()
    content = data['content']
    filename = f"output_{uuid.uuid4().hex}.pdf"
    filepath = os.path.join("static", filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    return jsonify({"file_url": f"/static/{filename}"})

@app.route('/text-to-video', methods=['POST'])
def text_to_video():
    data = request.get_json()
    text = data['text']
    lang = translator.detect(text).lang
    en_text = translator.translate(text, dest='en').text
    audio_path = f"static/audio_{uuid.uuid4().hex}.mp3"
    tts = gTTS(en_text)
    tts.save(audio_path)
    video_path = f"static/video_{uuid.uuid4().hex}.mp4"
    image = "background.jpg"
    subprocess.call([
        'ffmpeg', '-loop', '1', '-i', image, '-i', audio_path,
        '-c:v', 'libx264', '-c:a', 'aac', '-strict', 'experimental',
        '-b:a', '192k', '-shortest', video_path
    ])
    return jsonify({"video_url": f"/{video_path}"})

@app.route('/image-to-cdr', methods=['POST'])
def image_to_cdr():
    data = request.get_json()
    image_url = data['image_url']
    image_name = f"img_{uuid.uuid4().hex}.png"
    cdr_file = image_name.replace(".png", ".cdr")
    image_path = os.path.join("static", image_name)
    cdr_path = os.path.join("static", cdr_file)

    from urllib.request import urlretrieve
    urlretrieve(image_url, image_path)

    os.rename(image_path, cdr_path)
    return jsonify({"cdr_url": f"/static/{cdr_file}"})

if __name__ == '__main__':
    if not os.path.exists('static'):
        os.makedirs('static')
    app.run(debug=True)